from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import render


def index(request):
    return render(request,"index.html")

def home(request):
    return render(request,"index.html")

def login(request):
    return render(request,"login.html")

def gallery(request):
    return render(request,"gallery.html")

def payments(request):
    return render(request,"payments.html")

def artistlogin(request):
    return render(request,"artistlogin.html")

def customerlogin(request):
    return render(request,"customerlogin.html")

def feedback1(request):
    return render(request,"feedback1.html")
